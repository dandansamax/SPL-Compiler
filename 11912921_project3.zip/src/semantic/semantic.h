#include "../utils/tokentree.h"
#include "../utils/symbol_table.h"

int semantic_analysis(Node* root, FILE *file);