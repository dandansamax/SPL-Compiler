#include "../utils/tokentree.h"
#include "../utils/symbol_table.h"

int tac_generator(Node* root, FILE *file);